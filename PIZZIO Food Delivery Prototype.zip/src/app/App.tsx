import { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { SearchScreen } from './components/SearchScreen';
import { PizzaDetailsScreen, CartItem } from './components/PizzaDetailsScreen';
import { CartScreen } from './components/CartScreen';
import { CheckoutScreen } from './components/CheckoutScreen';
import { OrderTrackingScreen } from './components/OrderTrackingScreen';
import { OrderSuccessScreen } from './components/OrderSuccessScreen';
import { AIChatbot } from './components/AIChatbot';
import { pizzaData } from './data/pizzas';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';

type Screen =
  | 'splash'
  | 'login'
  | 'home'
  | 'search'
  | 'pizza-details'
  | 'cart'
  | 'checkout'
  | 'order-tracking'
  | 'order-success';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [selectedPizza, setSelectedPizza] = useState(pizzaData[0]);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orderId, setOrderId] = useState('');
  const [checkoutTotal, setCheckoutTotal] = useState(0);

  // Fetch pizza images
  useEffect(() => {
    const images = [
      'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJnaGVyaXRhJTIwcGl6emF8ZW58MXx8fHwxNzY1OTkxMjU0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1758982126977-168e00f33230?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwdGlra2ElMjBwaXp6YXxlbnwxfHx8fDE3NjYwNTgxMjR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1628840042765-356cda07504e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXBwZXJvbmklMjBwaXp6YXxlbnwxfHx8fDE3NjYwMzA3NDR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1730929851365-015a0b62ae5b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFibGUlMjBwaXp6YXxlbnwxfHx8fDE3NjYwNTgxMjV8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1732223229355-95a1433404bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVlc2UlMjBwaXp6YXxlbnwxfHx8fDE3NjYwMDgyNTh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYnElMjBjaGlja2VuJTIwcGl6emF8ZW58MXx8fHwxNzY1OTY5ODkxfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1665033628673-7de125eb6b12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYW5lZXIlMjBwaXp6YXxlbnwxfHx8fDE3NjYwNTgxMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1663858835211-3883764dcd52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMGNvbWJvfGVufDF8fHx8MTc2NjA1ODEyNnww&ixlib=rb-4.1.0&q=80&w=1080',
    ];

    pizzaData.forEach((pizza, index) => {
      pizza.image = images[index] || images[0];
    });
  }, []);

  const handleAddToCart = (item: CartItem) => {
    setCartItems((prev) => [...prev, item]);
    toast.success('Added to cart!', {
      description: `${item.pizza.name} has been added to your cart.`,
    });
    setCurrentScreen('home');
  };

  const handleUpdateQuantity = (index: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCartItems((prev) =>
      prev.map((item, i) => {
        if (i === index) {
          const basePrice = item.pizza.sizes[item.size];
          const toppingsPrice = item.toppings.reduce((sum, topping) => {
            const toppingData = item.pizza.toppings.find((t) => t.name === topping);
            return sum + (toppingData?.price || 0);
          }, 0);
          return {
            ...item,
            quantity,
            totalPrice: (basePrice + toppingsPrice) * quantity,
          };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
    toast.error('Item removed', {
      description: 'Item has been removed from your cart.',
    });
  };

  const handleCheckout = (discount: number, couponCode: string) => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.totalPrice, 0);
    const deliveryFee = subtotal > 500 ? 0 : 40;
    const total = subtotal - discount + deliveryFee;
    setCheckoutTotal(total);
    setCurrentScreen('checkout');
  };

  const handlePlaceOrder = (paymentMethod: string) => {
    const newOrderId = 'PIZZIO' + Math.random().toString(36).substring(2, 9).toUpperCase();
    setOrderId(newOrderId);
    toast.success('Order placed!', {
      description: `Your order #${newOrderId} has been placed successfully.`,
    });
    setCurrentScreen('order-tracking');
  };

  const handleOrderComplete = () => {
    setCurrentScreen('order-success');
  };

  const handleBackToHome = () => {
    setCartItems([]);
    setCurrentScreen('home');
  };

  return (
    <div className="min-h-screen">
      {currentScreen === 'splash' && (
        <SplashScreen onComplete={() => setCurrentScreen('login')} />
      )}

      {currentScreen === 'login' && (
        <LoginScreen
          onLogin={() => setCurrentScreen('home')}
          onGuestLogin={() => setCurrentScreen('home')}
        />
      )}

      {currentScreen === 'home' && (
        <HomeScreen
          pizzas={pizzaData}
          onSearch={() => setCurrentScreen('search')}
          onPizzaClick={(pizza) => {
            setSelectedPizza(pizza);
            setCurrentScreen('pizza-details');
          }}
          onCartClick={() => setCurrentScreen('cart')}
          cartCount={cartItems.length}
        />
      )}

      {currentScreen === 'search' && (
        <SearchScreen
          pizzas={pizzaData}
          onBack={() => setCurrentScreen('home')}
          onPizzaClick={(pizza) => {
            setSelectedPizza(pizza);
            setCurrentScreen('pizza-details');
          }}
        />
      )}

      {currentScreen === 'pizza-details' && (
        <PizzaDetailsScreen
          pizza={selectedPizza}
          onBack={() => setCurrentScreen('home')}
          onAddToCart={handleAddToCart}
        />
      )}

      {currentScreen === 'cart' && (
        <CartScreen
          cartItems={cartItems}
          onBack={() => setCurrentScreen('home')}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
          onCheckout={handleCheckout}
        />
      )}

      {currentScreen === 'checkout' && (
        <CheckoutScreen
          total={checkoutTotal}
          onBack={() => setCurrentScreen('cart')}
          onPlaceOrder={handlePlaceOrder}
        />
      )}

      {currentScreen === 'order-tracking' && (
        <OrderTrackingScreen
          orderId={orderId}
          onBack={() => setCurrentScreen('home')}
          onOrderComplete={handleOrderComplete}
        />
      )}

      {currentScreen === 'order-success' && (
        <OrderSuccessScreen orderId={orderId} onBackToHome={handleBackToHome} />
      )}

      {/* AI Chatbot - Available on all screens except splash and login */}
      {currentScreen !== 'splash' && currentScreen !== 'login' && <AIChatbot />}

      {/* Toast Notifications */}
      <Toaster position="top-center" richColors />
    </div>
  );
}
