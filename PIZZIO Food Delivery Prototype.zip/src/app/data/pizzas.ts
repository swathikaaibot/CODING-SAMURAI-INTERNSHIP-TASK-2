export interface Pizza {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: 'Veg' | 'Non-Veg' | 'Cheese Burst' | 'Combo';
  rating: number;
  reviews: number;
  deliveryTime: string;
  isVeg: boolean;
  sizes: {
    small: number;
    medium: number;
    large: number;
  };
  crusts: string[];
  toppings: { name: string; price: number }[];
}

export const pizzaData: Pizza[] = [
  {
    id: '1',
    name: 'Margherita Pizza',
    description: 'Classic tomato sauce, fresh mozzarella, and basil',
    price: 299,
    image: '',
    category: 'Veg',
    rating: 4.5,
    reviews: 234,
    deliveryTime: '25-30 mins',
    isVeg: true,
    sizes: { small: 199, medium: 299, large: 399 },
    crusts: ['Thin Crust', 'Regular', 'Cheese Burst', 'Stuffed Crust'],
    toppings: [
      { name: 'Extra Cheese', price: 50 },
      { name: 'Olives', price: 40 },
      { name: 'Mushrooms', price: 45 },
      { name: 'Bell Peppers', price: 35 },
    ],
  },
  {
    id: '2',
    name: 'Chicken Tikka Pizza',
    description: 'Spicy chicken tikka, onions, peppers, and cheese',
    price: 449,
    image: '',
    category: 'Non-Veg',
    rating: 4.7,
    reviews: 456,
    deliveryTime: '30-35 mins',
    isVeg: false,
    sizes: { small: 299, medium: 449, large: 599 },
    crusts: ['Thin Crust', 'Regular', 'Cheese Burst', 'Stuffed Crust'],
    toppings: [
      { name: 'Extra Chicken', price: 80 },
      { name: 'Extra Cheese', price: 50 },
      { name: 'Jalapeños', price: 40 },
      { name: 'Onions', price: 30 },
    ],
  },
  {
    id: '3',
    name: 'Pepperoni Delight',
    description: 'Loaded with pepperoni and melted cheese',
    price: 499,
    image: '',
    category: 'Non-Veg',
    rating: 4.8,
    reviews: 678,
    deliveryTime: '25-30 mins',
    isVeg: false,
    sizes: { small: 349, medium: 499, large: 649 },
    crusts: ['Thin Crust', 'Regular', 'Cheese Burst', 'Stuffed Crust'],
    toppings: [
      { name: 'Extra Pepperoni', price: 90 },
      { name: 'Extra Cheese', price: 50 },
      { name: 'Mushrooms', price: 45 },
    ],
  },
  {
    id: '4',
    name: 'Veggie Supreme',
    description: 'Fresh vegetables, olives, and cheese on tomato base',
    price: 349,
    image: '',
    category: 'Veg',
    rating: 4.4,
    reviews: 189,
    deliveryTime: '25-30 mins',
    isVeg: true,
    sizes: { small: 249, medium: 349, large: 449 },
    crusts: ['Thin Crust', 'Regular', 'Cheese Burst', 'Stuffed Crust'],
    toppings: [
      { name: 'Extra Cheese', price: 50 },
      { name: 'Corn', price: 35 },
      { name: 'Jalapeños', price: 40 },
    ],
  },
  {
    id: '5',
    name: 'Cheese Burst Special',
    description: 'Double cheese with cheese-filled crust',
    price: 549,
    image: '',
    category: 'Cheese Burst',
    rating: 4.9,
    reviews: 892,
    deliveryTime: '30-35 mins',
    isVeg: true,
    sizes: { small: 399, medium: 549, large: 699 },
    crusts: ['Cheese Burst'],
    toppings: [
      { name: 'Extra Cheese', price: 50 },
      { name: 'Paneer', price: 60 },
    ],
  },
  {
    id: '6',
    name: 'BBQ Chicken Pizza',
    description: 'Smoky BBQ chicken with onions and peppers',
    price: 479,
    image: '',
    category: 'Non-Veg',
    rating: 4.6,
    reviews: 345,
    deliveryTime: '30-35 mins',
    isVeg: false,
    sizes: { small: 329, medium: 479, large: 629 },
    crusts: ['Thin Crust', 'Regular', 'Cheese Burst', 'Stuffed Crust'],
    toppings: [
      { name: 'Extra Chicken', price: 80 },
      { name: 'Extra Cheese', price: 50 },
    ],
  },
  {
    id: '7',
    name: 'Paneer Tikka Pizza',
    description: 'Spicy paneer tikka with Indian spices',
    price: 399,
    image: '',
    category: 'Veg',
    rating: 4.5,
    reviews: 267,
    deliveryTime: '25-30 mins',
    isVeg: true,
    sizes: { small: 279, medium: 399, large: 519 },
    crusts: ['Thin Crust', 'Regular', 'Cheese Burst', 'Stuffed Crust'],
    toppings: [
      { name: 'Extra Paneer', price: 60 },
      { name: 'Extra Cheese', price: 50 },
    ],
  },
  {
    id: '8',
    name: 'Pizza Combo Special',
    description: '2 Medium pizzas + Garlic Bread + Coke',
    price: 799,
    image: '',
    category: 'Combo',
    rating: 4.7,
    reviews: 445,
    deliveryTime: '35-40 mins',
    isVeg: true,
    sizes: { small: 0, medium: 799, large: 999 },
    crusts: ['Regular'],
    toppings: [],
  },
];

export const coupons = [
  {
    id: 'FIRST50',
    code: 'FIRST50',
    discount: 50,
    description: '50% off on first order',
    minOrder: 299,
  },
  {
    id: 'PIZZA30',
    code: 'PIZZA30',
    discount: 30,
    description: '₹30 off on orders above ₹399',
    minOrder: 399,
  },
  {
    id: 'COMBO100',
    code: 'COMBO100',
    discount: 100,
    description: '₹100 off on combo orders',
    minOrder: 599,
  },
];
