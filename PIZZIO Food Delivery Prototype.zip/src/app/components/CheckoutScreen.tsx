import { motion } from 'motion/react';
import { ArrowLeft, MapPin, CreditCard, Wallet, Banknote } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { useState } from 'react';

interface CheckoutScreenProps {
  total: number;
  onBack: () => void;
  onPlaceOrder: (paymentMethod: string) => void;
}

export function CheckoutScreen({ total, onBack, onPlaceOrder }: CheckoutScreenProps) {
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePlaceOrder = () => {
    setIsProcessing(true);
    setTimeout(() => {
      onPlaceOrder(paymentMethod);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
            disabled={isProcessing}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl">Checkout</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-4">
        {/* Delivery Address */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow"
        >
          <h3 className="text-lg text-gray-900 mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-orange-500" />
            Delivery Address
          </h3>
          <div className="space-y-3">
            <Input placeholder="Full Name" defaultValue="Guest User" />
            <Input placeholder="Phone Number" defaultValue="+91 9876543210" />
            <Textarea
              placeholder="Complete Address"
              defaultValue="Ramanathapuram, Coimbatore, Tamil Nadu - 641045"
              rows={3}
            />
            <Input placeholder="Landmark (Optional)" />
          </div>
        </motion.div>

        {/* Payment Method */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl p-4 shadow"
        >
          <h3 className="text-lg text-gray-900 mb-4 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-orange-500" />
            Payment Method
          </h3>
          <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
            <div className="space-y-3">
              <div className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <RadioGroupItem value="upi" id="upi" />
                <Label htmlFor="upi" className="cursor-pointer ml-3 flex items-center gap-3 flex-1">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                    <Wallet className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p>UPI</p>
                    <p className="text-sm text-gray-500">Pay using UPI apps</p>
                  </div>
                </Label>
              </div>

              <div className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <RadioGroupItem value="card" id="card" />
                <Label htmlFor="card" className="cursor-pointer ml-3 flex items-center gap-3 flex-1">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p>Credit/Debit Card</p>
                    <p className="text-sm text-gray-500">Visa, Mastercard, RuPay</p>
                  </div>
                </Label>
              </div>

              <div className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <RadioGroupItem value="cod" id="cod" />
                <Label htmlFor="cod" className="cursor-pointer ml-3 flex items-center gap-3 flex-1">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg flex items-center justify-center">
                    <Banknote className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p>Cash on Delivery</p>
                    <p className="text-sm text-gray-500">Pay when you receive</p>
                  </div>
                </Label>
              </div>
            </div>
          </RadioGroup>

          {paymentMethod === 'upi' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-4"
            >
              <Input placeholder="Enter UPI ID (e.g., name@upi)" />
            </motion.div>
          )}

          {paymentMethod === 'card' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-4 space-y-3"
            >
              <Input placeholder="Card Number" />
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="MM/YY" />
                <Input placeholder="CVV" />
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Order Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-4 shadow"
        >
          <h3 className="text-lg text-gray-900 mb-4">Order Summary</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-gray-600">
              <span>Amount to Pay</span>
              <span className="text-2xl text-orange-600">₹{total.toFixed(2)}</span>
            </div>
            <p className="text-sm text-gray-500">
              Estimated delivery: 25-30 mins
            </p>
          </div>
        </motion.div>
      </div>

      {/* Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Total Amount</p>
            <p className="text-2xl text-orange-600">₹{total.toFixed(2)}</p>
          </div>
          <Button
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 px-8"
            onClick={handlePlaceOrder}
            disabled={isProcessing}
          >
            {isProcessing ? 'Processing...' : 'Place Order'}
          </Button>
        </div>
      </div>
    </div>
  );
}
