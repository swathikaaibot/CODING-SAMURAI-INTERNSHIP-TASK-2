import { motion } from 'motion/react';
import { Search, ShoppingCart, User, MapPin, Pizza, Leaf, Flame, Tag } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Pizza as PizzaType } from '../data/pizzas';

interface HomeScreenProps {
  pizzas: PizzaType[];
  onSearch: () => void;
  onPizzaClick: (pizza: PizzaType) => void;
  onCartClick: () => void;
  cartCount: number;
}

export function HomeScreen({ pizzas, onSearch, onPizzaClick, onCartClick, cartCount }: HomeScreenProps) {
  const categories = ['All', 'Veg', 'Non-Veg', 'Cheese Burst', 'Combo'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl">PIZZIO</h1>
              <div className="flex items-center gap-2 mt-1">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">Ramanathapuram, Coimbatore</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 relative">
                <User className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/20 relative"
                onClick={onCartClick}
              >
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-yellow-400 text-orange-900 text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative" onClick={onSearch}>
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search for pizzas..."
              className="pl-10 bg-white text-gray-900"
              readOnly
            />
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4">
        {/* Offers Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-xl p-6 mb-6 shadow-lg"
        >
          <div className="flex items-start gap-3">
            <Tag className="w-6 h-6 text-orange-900 mt-1" />
            <div>
              <h3 className="text-xl text-orange-900 mb-2">Special Offers!</h3>
              <div className="space-y-1">
                <p className="text-sm text-orange-900">🎉 50% off on first order - Use code FIRST50</p>
                <p className="text-sm text-orange-900">🍕 ₹100 off on combo orders - Use code COMBO100</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Categories */}
        <div className="mb-6">
          <h2 className="text-xl text-gray-900 mb-3">Categories</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {categories.map((category, index) => (
              <motion.button
                key={category}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`px-4 py-2 rounded-full whitespace-nowrap ${
                  index === 0
                    ? 'bg-orange-500 text-white'
                    : 'bg-white text-gray-700 border border-gray-200'
                }`}
              >
                {category === 'Veg' && <Leaf className="w-4 h-4 inline mr-1" />}
                {category === 'Non-Veg' && <Flame className="w-4 h-4 inline mr-1" />}
                {category}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Featured Pizzas */}
        <div className="mb-6">
          <h2 className="text-xl text-gray-900 mb-3">Featured Pizzas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pizzas.slice(0, 6).map((pizza, index) => (
              <motion.div
                key={pizza.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.03 }}
                className="bg-white rounded-xl shadow-md overflow-hidden cursor-pointer"
                onClick={() => onPizzaClick(pizza)}
              >
                <div className="relative h-48">
                  <img
                    src={pizza.image}
                    alt={pizza.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <Badge
                      className={pizza.isVeg ? 'bg-green-500' : 'bg-red-500'}
                    >
                      {pizza.isVeg ? '🌿 Veg' : '🍗 Non-Veg'}
                    </Badge>
                  </div>
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur px-2 py-1 rounded">
                    <span className="text-sm">⭐ {pizza.rating}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg text-gray-900 mb-1">{pizza.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{pizza.description}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xl text-orange-600">₹{pizza.price}</span>
                      <p className="text-xs text-gray-500">{pizza.deliveryTime}</p>
                    </div>
                    <Button className="bg-orange-500 hover:bg-orange-600">
                      Add
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* All Pizzas */}
        <div>
          <h2 className="text-xl text-gray-900 mb-3">All Pizzas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {pizzas.map((pizza, index) => (
              <motion.div
                key={pizza.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ y: -5 }}
                className="bg-white rounded-lg shadow overflow-hidden cursor-pointer"
                onClick={() => onPizzaClick(pizza)}
              >
                <div className="relative h-40">
                  <img
                    src={pizza.image}
                    alt={pizza.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <span className="text-xl">{pizza.isVeg ? '🟢' : '🔴'}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h4 className="text-gray-900 mb-1 truncate">{pizza.name}</h4>
                  <div className="flex items-center justify-between">
                    <span className="text-orange-600">₹{pizza.price}</span>
                    <span className="text-sm text-gray-500">⭐ {pizza.rating}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
