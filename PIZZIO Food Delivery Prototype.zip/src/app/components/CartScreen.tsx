import { motion } from 'motion/react';
import { ArrowLeft, Trash2, Plus, Minus, Tag } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { CartItem } from './PizzaDetailsScreen';
import { useState } from 'react';

interface CartScreenProps {
  cartItems: CartItem[];
  onBack: () => void;
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onCheckout: (discount: number, couponCode: string) => void;
}

const availableCoupons = [
  { code: 'FIRST50', discount: 50, minOrder: 299, description: '50% off on first order' },
  { code: 'PIZZA30', discount: 30, minOrder: 399, description: '₹30 off on orders above ₹399' },
  { code: 'COMBO100', discount: 100, minOrder: 599, description: '₹100 off on combo orders' },
];

export function CartScreen({
  cartItems,
  onBack,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartScreenProps) {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  const subtotal = cartItems.reduce((sum, item) => sum + item.totalPrice, 0);
  
  const applyCoupon = (code: string) => {
    const coupon = availableCoupons.find((c) => c.code === code);
    if (coupon && subtotal >= coupon.minOrder) {
      setAppliedCoupon(code);
      setCouponCode(code);
    }
  };

  const discount = appliedCoupon
    ? availableCoupons.find((c) => c.code === appliedCoupon)?.discount || 0
    : 0;
  
  const discountType = appliedCoupon === 'FIRST50' ? 'percentage' : 'fixed';
  const discountAmount = discountType === 'percentage' ? (subtotal * discount) / 100 : discount;
  const deliveryFee = subtotal > 500 ? 0 : 40;
  const total = subtotal - discountAmount + deliveryFee;

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl">Cart</h1>
          </div>
        </div>
        <div className="max-w-4xl mx-auto p-4 text-center py-20">
          <p className="text-xl text-gray-600 mb-4">Your cart is empty</p>
          <Button onClick={onBack} className="bg-orange-500 hover:bg-orange-600">
            Start Ordering
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl">Cart ({cartItems.length} {cartItems.length === 1 ? 'item' : 'items'})</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-4">
        {/* Cart Items */}
        <div className="space-y-3">
          {cartItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="bg-white rounded-xl p-4 shadow"
            >
              <div className="flex gap-4">
                <img
                  src={item.pizza.image}
                  alt={item.pizza.name}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-lg text-gray-900">{item.pizza.name}</h3>
                      <p className="text-sm text-gray-600 capitalize">
                        {item.size} | {item.crust}
                      </p>
                      {item.toppings.length > 0 && (
                        <p className="text-sm text-gray-500">
                          + {item.toppings.join(', ')}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRemoveItem(index)}
                      className="text-red-500 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 border rounded-lg px-2 py-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                        disabled={item.quantity <= 1}
                        className="h-8 w-8"
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                        className="h-8 w-8"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <span className="text-xl text-orange-600">₹{item.totalPrice}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Available Coupons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow"
        >
          <h3 className="text-lg text-gray-900 mb-3 flex items-center gap-2">
            <Tag className="w-5 h-5 text-orange-500" />
            Available Coupons
          </h3>
          <div className="space-y-2 mb-4">
            {availableCoupons.map((coupon) => (
              <div
                key={coupon.code}
                className={`p-3 border rounded-lg cursor-pointer transition ${
                  appliedCoupon === coupon.code
                    ? 'border-orange-500 bg-orange-50'
                    : 'hover:bg-gray-50'
                } ${subtotal < coupon.minOrder ? 'opacity-50' : ''}`}
                onClick={() => subtotal >= coupon.minOrder && applyCoupon(coupon.code)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-600">{coupon.code}</p>
                    <p className="text-sm text-gray-600">{coupon.description}</p>
                    {subtotal < coupon.minOrder && (
                      <p className="text-xs text-red-500">
                        Min order: ₹{coupon.minOrder}
                      </p>
                    )}
                  </div>
                  {appliedCoupon === coupon.code && (
                    <span className="text-green-600">✓ Applied</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Input
              placeholder="Enter coupon code"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
            />
            <Button
              onClick={() => applyCoupon(couponCode)}
              variant="outline"
              className="whitespace-nowrap"
            >
              Apply
            </Button>
          </div>
        </motion.div>

        {/* Bill Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow"
        >
          <h3 className="text-lg text-gray-900 mb-4">Bill Summary</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-gray-600">
              <span>Subtotal</span>
              <span>₹{subtotal}</span>
            </div>
            {appliedCoupon && (
              <div className="flex items-center justify-between text-green-600">
                <span>Discount ({appliedCoupon})</span>
                <span>-₹{discountAmount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex items-center justify-between text-gray-600">
              <span>Delivery Fee</span>
              <span>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
            </div>
            {deliveryFee === 0 && (
              <p className="text-xs text-green-600">Free delivery on orders above ₹500</p>
            )}
            <div className="pt-2 border-t">
              <div className="flex items-center justify-between text-gray-900">
                <span>Total</span>
                <span className="text-2xl text-orange-600">₹{total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Total Amount</p>
            <p className="text-2xl text-orange-600">₹{total.toFixed(2)}</p>
          </div>
          <Button
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 px-8"
            onClick={() => onCheckout(discountAmount, appliedCoupon || '')}
          >
            Proceed to Checkout
          </Button>
        </div>
      </div>
    </div>
  );
}
