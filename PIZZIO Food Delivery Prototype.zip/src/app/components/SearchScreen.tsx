import { motion } from 'motion/react';
import { useState } from 'react';
import { ArrowLeft, Search, SlidersHorizontal } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Pizza } from '../data/pizzas';
import { Badge } from './ui/badge';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from './ui/sheet';
import { Slider } from './ui/slider';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';

interface SearchScreenProps {
  pizzas: Pizza[];
  onBack: () => void;
  onPizzaClick: (pizza: Pizza) => void;
}

export function SearchScreen({ pizzas, onBack, onPizzaClick }: SearchScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [vegFilter, setVegFilter] = useState<string>('all');
  const [minRating, setMinRating] = useState(0);

  const filteredPizzas = pizzas.filter((pizza) => {
    const matchesSearch = pizza.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pizza.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPrice = pizza.price >= priceRange[0] && pizza.price <= priceRange[1];
    const matchesVeg = vegFilter === 'all' || 
      (vegFilter === 'veg' && pizza.isVeg) || 
      (vegFilter === 'non-veg' && !pizza.isVeg);
    const matchesRating = pizza.rating >= minRating;
    
    return matchesSearch && matchesPrice && matchesVeg && matchesRating;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl">Search Pizzas</h1>
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search for pizzas..."
                className="pl-10 bg-white text-gray-900"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
              />
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="secondary" size="icon">
                  <SlidersHorizontal className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>
                    Filter pizzas by your preferences
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  {/* Price Range */}
                  <div>
                    <Label>Price Range: ₹{priceRange[0]} - ₹{priceRange[1]}</Label>
                    <Slider
                      min={0}
                      max={1000}
                      step={50}
                      value={priceRange}
                      onValueChange={setPriceRange}
                      className="mt-2"
                    />
                  </div>

                  {/* Veg/Non-Veg */}
                  <div>
                    <Label className="mb-3 block">Type</Label>
                    <RadioGroup value={vegFilter} onValueChange={setVegFilter}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="all" id="all" />
                        <Label htmlFor="all">All</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="veg" id="veg" />
                        <Label htmlFor="veg">Veg Only</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="non-veg" id="non-veg" />
                        <Label htmlFor="non-veg">Non-Veg Only</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Rating */}
                  <div>
                    <Label>Minimum Rating: {minRating}+</Label>
                    <Slider
                      min={0}
                      max={5}
                      step={0.5}
                      value={[minRating]}
                      onValueChange={(val) => setMinRating(val[0])}
                      className="mt-2"
                    />
                  </div>

                  <Button
                    className="w-full"
                    onClick={() => {
                      setPriceRange([0, 1000]);
                      setVegFilter('all');
                      setMinRating(0);
                    }}
                    variant="outline"
                  >
                    Clear Filters
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="max-w-6xl mx-auto p-4">
        <div className="mb-4">
          <p className="text-gray-600">
            {filteredPizzas.length} {filteredPizzas.length === 1 ? 'result' : 'results'} found
          </p>
        </div>

        {searchQuery && filteredPizzas.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No pizzas found for "{searchQuery}"</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPizzas.map((pizza, index) => (
              <motion.div
                key={pizza.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.03 }}
                className="bg-white rounded-xl shadow-md overflow-hidden cursor-pointer"
                onClick={() => onPizzaClick(pizza)}
              >
                <div className="relative h-48">
                  <img
                    src={pizza.image}
                    alt={pizza.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <Badge className={pizza.isVeg ? 'bg-green-500' : 'bg-red-500'}>
                      {pizza.isVeg ? '🌿 Veg' : '🍗 Non-Veg'}
                    </Badge>
                  </div>
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur px-2 py-1 rounded">
                    <span className="text-sm">⭐ {pizza.rating}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg text-gray-900 mb-1">{pizza.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                    {pizza.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xl text-orange-600">₹{pizza.price}</span>
                      <p className="text-xs text-gray-500">{pizza.deliveryTime}</p>
                    </div>
                    <Button className="bg-orange-500 hover:bg-orange-600">Add</Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
