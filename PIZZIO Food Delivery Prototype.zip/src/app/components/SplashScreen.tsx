import { motion } from 'motion/react';
import { Pizza } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 flex items-center justify-center z-50"
      onAnimationComplete={() => {
        setTimeout(onComplete, 2000);
      }}
    >
      <div className="text-center">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="mb-6"
        >
          <Pizza className="w-32 h-32 text-white mx-auto" />
        </motion.div>
        <motion.h1
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-6xl text-white mb-2 tracking-wider"
        >
          PIZZIO
        </motion.h1>
        <motion.p
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.6 }}
          className="text-xl text-white/90"
        >
          Coimbatore's Best Pizza Delivery
        </motion.p>
      </div>
    </motion.div>
  );
}
