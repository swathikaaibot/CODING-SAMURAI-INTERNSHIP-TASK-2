import { motion } from 'motion/react';
import { useState } from 'react';
import { ArrowLeft, Star, Clock, Minus, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Pizza } from '../data/pizzas';

interface PizzaDetailsScreenProps {
  pizza: Pizza;
  onBack: () => void;
  onAddToCart: (item: CartItem) => void;
}

export interface CartItem {
  pizza: Pizza;
  size: 'small' | 'medium' | 'large';
  crust: string;
  toppings: string[];
  quantity: number;
  totalPrice: number;
}

export function PizzaDetailsScreen({ pizza, onBack, onAddToCart }: PizzaDetailsScreenProps) {
  const [selectedSize, setSelectedSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [selectedCrust, setSelectedCrust] = useState(pizza.crusts[0]);
  const [selectedToppings, setSelectedToppings] = useState<string[]>([]);
  const [quantity, setQuantity] = useState(1);

  const basePrice = pizza.sizes[selectedSize];
  const toppingsPrice = selectedToppings.reduce((sum, topping) => {
    const toppingData = pizza.toppings.find((t) => t.name === topping);
    return sum + (toppingData?.price || 0);
  }, 0);
  const totalPrice = (basePrice + toppingsPrice) * quantity;

  const handleAddToCart = () => {
    const cartItem: CartItem = {
      pizza,
      size: selectedSize,
      crust: selectedCrust,
      toppings: selectedToppings,
      quantity,
      totalPrice,
    };
    onAddToCart(cartItem);
  };

  const toggleTopping = (topping: string) => {
    setSelectedToppings((prev) =>
      prev.includes(topping)
        ? prev.filter((t) => t !== topping)
        : [...prev, topping]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl">Pizza Details</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Pizza Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative h-80 overflow-hidden"
        >
          <img
            src={pizza.image}
            alt={pizza.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4">
            <Badge className={pizza.isVeg ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}>
              {pizza.isVeg ? '🌿 Veg' : '🍗 Non-Veg'}
            </Badge>
          </div>
        </motion.div>

        {/* Details */}
        <div className="p-4 space-y-6">
          {/* Basic Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-4 shadow"
          >
            <h2 className="text-2xl text-gray-900 mb-2">{pizza.name}</h2>
            <p className="text-gray-600 mb-4">{pizza.description}</p>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span>{pizza.rating} ({pizza.reviews} reviews)</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-orange-500" />
                <span>{pizza.deliveryTime}</span>
              </div>
            </div>
          </motion.div>

          {/* Size Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-xl p-4 shadow"
          >
            <h3 className="text-lg text-gray-900 mb-3">Select Size</h3>
            <RadioGroup value={selectedSize} onValueChange={(val) => setSelectedSize(val as any)}>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className="flex items-center space-x-3">
                    <RadioGroupItem value="small" id="small" />
                    <Label htmlFor="small" className="cursor-pointer">Small (7")</Label>
                  </div>
                  <span className="text-orange-600">₹{pizza.sizes.small}</span>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className="flex items-center space-x-3">
                    <RadioGroupItem value="medium" id="medium" />
                    <Label htmlFor="medium" className="cursor-pointer">Medium (10")</Label>
                  </div>
                  <span className="text-orange-600">₹{pizza.sizes.medium}</span>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className="flex items-center space-x-3">
                    <RadioGroupItem value="large" id="large" />
                    <Label htmlFor="large" className="cursor-pointer">Large (13")</Label>
                  </div>
                  <span className="text-orange-600">₹{pizza.sizes.large}</span>
                </div>
              </div>
            </RadioGroup>
          </motion.div>

          {/* Crust Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-xl p-4 shadow"
          >
            <h3 className="text-lg text-gray-900 mb-3">Select Crust</h3>
            <RadioGroup value={selectedCrust} onValueChange={setSelectedCrust}>
              <div className="space-y-2">
                {pizza.crusts.map((crust) => (
                  <div
                    key={crust}
                    className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                  >
                    <RadioGroupItem value={crust} id={crust} />
                    <Label htmlFor={crust} className="cursor-pointer ml-3">
                      {crust}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </motion.div>

          {/* Toppings */}
          {pizza.toppings.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-xl p-4 shadow"
            >
              <h3 className="text-lg text-gray-900 mb-3">Add Toppings</h3>
              <div className="space-y-2">
                {pizza.toppings.map((topping) => (
                  <div
                    key={topping.name}
                    className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                    onClick={() => toggleTopping(topping.name)}
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        checked={selectedToppings.includes(topping.name)}
                        onCheckedChange={() => toggleTopping(topping.name)}
                      />
                      <Label className="cursor-pointer">{topping.name}</Label>
                    </div>
                    <span className="text-orange-600">+₹{topping.price}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Quantity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-xl p-4 shadow"
          >
            <h3 className="text-lg text-gray-900 mb-3">Quantity</h3>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
              >
                <Minus className="w-4 h-4" />
              </Button>
              <span className="text-xl w-12 text-center">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(quantity + 1)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Total Amount</p>
            <p className="text-2xl text-orange-600">₹{totalPrice}</p>
          </div>
          <Button
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 px-8"
            onClick={handleAddToCart}
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </div>
  );
}
