import { motion } from 'motion/react';
import { CheckCircle, Gift, Home } from 'lucide-react';
import { Button } from './ui/button';

interface OrderSuccessScreenProps {
  orderId: string;
  onBackToHome: () => void;
}

export function OrderSuccessScreen({ orderId, onBackToHome }: OrderSuccessScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center"
      >
        {/* Success Icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          className="mb-6"
        >
          <div className="w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle className="w-16 h-16 text-white" />
          </div>
        </motion.div>

        {/* Success Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h1 className="text-3xl text-gray-900 mb-2">🎉 Congratulations!</h1>
          <p className="text-lg text-gray-600 mb-6">
            Your order has been placed successfully!
          </p>
        </motion.div>

        {/* Order Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-4 mb-6"
        >
          <p className="text-sm text-gray-600 mb-1">Order ID</p>
          <p className="text-xl text-gray-900 mb-4">#{orderId}</p>
          <div className="flex items-center justify-center gap-2 text-orange-600">
            <span>⏱️</span>
            <span>Estimated delivery: 25-30 mins</span>
          </div>
        </motion.div>

        {/* Reward Coupon */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8 }}
          className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-xl p-4 mb-6"
        >
          <div className="flex items-start gap-3">
            <Gift className="w-6 h-6 text-orange-900 mt-1" />
            <div className="text-left">
              <h3 className="text-lg text-orange-900 mb-1">Reward Unlocked!</h3>
              <p className="text-sm text-orange-900 mb-2">
                Get ₹50 off on your next order
              </p>
              <div className="bg-white/90 backdrop-blur rounded-lg px-3 py-2 inline-block">
                <p className="text-xs text-gray-600">Use code</p>
                <p className="text-orange-600">NEXT50</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="space-y-3"
        >
          <Button
            className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
            onClick={onBackToHome}
          >
            <Home className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </motion.div>

        {/* Thank You Message */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="text-sm text-gray-500 mt-6"
        >
          Thank you for choosing PIZZIO! 🍕
        </motion.p>
      </motion.div>
    </div>
  );
}
