import { motion } from 'motion/react';
import { ArrowLeft, CheckCircle, Clock, Package, Bike, Home } from 'lucide-react';
import { Button } from './ui/button';
import { useEffect, useState } from 'react';

interface OrderTrackingScreenProps {
  orderId: string;
  onBack: () => void;
  onOrderComplete: () => void;
}

const orderStatuses = [
  { id: 1, label: 'Order Confirmed', icon: CheckCircle, time: '0 mins' },
  { id: 2, label: 'Preparing', icon: Package, time: '5 mins' },
  { id: 3, label: 'Out for Delivery', icon: Bike, time: '15 mins' },
  { id: 4, label: 'Delivered', icon: Home, time: '25 mins' },
];

export function OrderTrackingScreen({ orderId, onBack, onOrderComplete }: OrderTrackingScreenProps) {
  const [currentStatus, setCurrentStatus] = useState(1);

  useEffect(() => {
    const timers = [
      setTimeout(() => setCurrentStatus(2), 3000),
      setTimeout(() => setCurrentStatus(3), 6000),
      setTimeout(() => setCurrentStatus(4), 9000),
      setTimeout(() => onOrderComplete(), 11000),
    ];

    return () => timers.forEach(clearTimeout);
  }, [onOrderComplete]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl">Track Order</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Order ID */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow text-center"
        >
          <p className="text-sm text-gray-600 mb-1">Order ID</p>
          <p className="text-xl text-gray-900">#{orderId}</p>
          <div className="mt-4 flex items-center justify-center gap-2 text-orange-600">
            <Clock className="w-5 h-5" />
            <span>Estimated delivery: 25-30 mins</span>
          </div>
        </motion.div>

        {/* Delivery Partner Info */}
        {currentStatus >= 3 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-xl p-4 shadow"
          >
            <h3 className="text-lg text-gray-900 mb-4">Delivery Partner</h3>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white text-2xl">
                R
              </div>
              <div className="flex-1">
                <p className="text-gray-900">Rajesh Kumar</p>
                <p className="text-sm text-gray-600">+91 98765 43210</p>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-sm text-yellow-600">⭐ 4.8</span>
                  <span className="text-xs text-gray-500">(256 deliveries)</span>
                </div>
              </div>
              <Button variant="outline" size="sm">
                Call
              </Button>
            </div>
          </motion.div>
        )}

        {/* Order Status Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-6 shadow"
        >
          <h3 className="text-lg text-gray-900 mb-6">Order Status</h3>
          <div className="relative">
            {/* Vertical Line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
            <motion.div
              className="absolute left-6 top-0 w-0.5 bg-gradient-to-b from-orange-500 to-red-500"
              initial={{ height: 0 }}
              animate={{ height: `${((currentStatus - 1) / 3) * 100}%` }}
              transition={{ duration: 0.5 }}
            ></motion.div>

            {/* Status Items */}
            <div className="space-y-8">
              {orderStatuses.map((status) => {
                const Icon = status.icon;
                const isCompleted = currentStatus >= status.id;
                const isCurrent = currentStatus === status.id;

                return (
                  <motion.div
                    key={status.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: status.id * 0.1 }}
                    className="relative flex items-start gap-4"
                  >
                    <motion.div
                      className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                        isCompleted
                          ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
                          : 'bg-gray-200 text-gray-400'
                      }`}
                      animate={isCurrent ? { scale: [1, 1.1, 1] } : {}}
                      transition={{ repeat: isCurrent ? Infinity : 0, duration: 2 }}
                    >
                      <Icon className="w-6 h-6" />
                    </motion.div>
                    <div className="flex-1 pt-2">
                      <p className={`${isCompleted ? 'text-gray-900' : 'text-gray-500'} mb-1`}>
                        {status.label}
                      </p>
                      {isCompleted && (
                        <motion.p
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-sm text-gray-600"
                        >
                          {isCurrent ? 'In progress...' : 'Completed'}
                        </motion.p>
                      )}
                    </div>
                    {isCompleted && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-sm text-gray-500 pt-2"
                      >
                        {status.time}
                      </motion.div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>
        </motion.div>

        {/* Map Placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl overflow-hidden shadow"
        >
          <div className="h-64 bg-gradient-to-br from-orange-100 to-red-100 flex items-center justify-center">
            <div className="text-center">
              <Bike className="w-16 h-16 text-orange-500 mx-auto mb-2" />
              <p className="text-gray-600">Live tracking map</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
